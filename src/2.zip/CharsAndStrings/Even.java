package CharsAndStrings;

public class Even {
    public static char hold[] = {'&', '|', '<', '>', '=', '!'};
}
