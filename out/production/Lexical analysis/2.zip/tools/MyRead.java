package tools;

import java.io.BufferedReader;
import java.io.FileReader;

public class MyRead {
    public static String readAsString(String path) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(path));
            StringBuilder stringBuilder = new StringBuilder();
            String line = null;
//            String ls = System.getProperty("line.separator");
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
//                stringBuilder.append(ls);
            }
            // 删除最后一个新行分隔符
//            stringBuilder.delete(stringBuilder.length() - ls.length(), stringBuilder.length());
            reader.close();

            String content = stringBuilder.toString();
            return content;
        }catch (Exception exception){
//            logger.error("readAsString error,path={},exception={}", path, ExceptionUtils.getStackTrace(exception));
            exception.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        System.out.println(readAsString("file/testfile.txt"));
    }
}
