package CharsAndStrings;

public class Odd {
    public static char hold[] = {'+', '-', '*', '/', '%', ';', ',', '(', ')', '[', ']', '{', '}'};
}
